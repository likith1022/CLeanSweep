import gym
from gym import spaces
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches

GRID_SIZE = 5
DIRT_REWARD = 10
OBSTACLE_PENALTY = -10
CLEAN_MOVE_REWARD = 1
PET_HAIR_BONUS = 5
MAX_STEPS = 200

EMPTY = 0
DIRTY = 1
OBSTACLE = -1
PET_HAIR = 2

class CleanSweepEnv(gym.Env):
    metadata = {'render_modes': ['human'], 'render_fps': 4}

    def __init__(self, render_mode=None):
        super().__init__()
        self.render_mode = render_mode
        self.grid = np.zeros((GRID_SIZE, GRID_SIZE))
        self.agent_pos = [0, 0]
        self.steps = 0
        self.action_space = spaces.Discrete(4)
        self.observation_space = spaces.Box(low=0, high=GRID_SIZE - 1, shape=(2,), dtype=np.int32)
        if self.render_mode == 'human':
            plt.ion()
            self.fig, self.ax = plt.subplots()
        self.reset()

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        self.grid = np.random.choice([EMPTY, DIRTY, PET_HAIR], size=(GRID_SIZE, GRID_SIZE), p=[0.3, 0.6, 0.1])
        self.grid[2][2] = OBSTACLE
        self.agent_pos = [0, 0]
        self.steps = 0
        return np.array(self.agent_pos, dtype=np.int32), {}

    def step(self, action):
        self.steps += 1
        x, y = self.agent_pos
        moves = {0: (-1, 0), 1: (1, 0), 2: (0, -1), 3: (0, 1)}
        dx, dy = moves[action]
        new_x, new_y = x + dx, y + dy
        reward = 0
        if 0 <= new_x < GRID_SIZE and 0 <= new_y < GRID_SIZE:
            if self.grid[new_x][new_y] == OBSTACLE:
                reward = OBSTACLE_PENALTY
            else:
                self.agent_pos = [new_x, new_y]
                if self.grid[new_x][new_y] == DIRTY:
                    reward = DIRT_REWARD
                elif self.grid[new_x][new_y] == PET_HAIR:
                    reward = DIRT_REWARD + PET_HAIR_BONUS
                else:
                    reward = CLEAN_MOVE_REWARD
                self.grid[new_x][new_y] = EMPTY
        else:
            reward = OBSTACLE_PENALTY
        done = np.count_nonzero((self.grid == DIRTY) | (self.grid == PET_HAIR)) == 0 or self.steps >= MAX_STEPS
        if self.render_mode == 'human':
            self.render()
        return np.array(self.agent_pos, dtype=np.int32), reward, done, False, {}

    def render(self):
        self.ax.clear()
        self.ax.set_xlim(0, GRID_SIZE)
        self.ax.set_ylim(0, GRID_SIZE)
        self.ax.set_xticks(np.arange(0, GRID_SIZE, 1))
        self.ax.set_yticks(np.arange(0, GRID_SIZE, 1))
        self.ax.grid(True)
        for i in range(GRID_SIZE):
            for j in range(GRID_SIZE):
                val = self.grid[i][j]
                color = 'white'
                if val == DIRTY:
                    color = 'sienna'
                elif val == OBSTACLE:
                    color = 'black'
                elif val == PET_HAIR:
                    color = 'orange'
                rect = patches.Rectangle((j, GRID_SIZE - 1 - i), 1, 1, facecolor=color)
                self.ax.add_patch(rect)
        self.ax.add_patch(patches.Circle((self.agent_pos[1] + 0.5, GRID_SIZE - 1 - self.agent_pos[0] + 0.5 - 1), 0.3, color='blue'))
        plt.draw()
        plt.pause(0.2)

    def close(self):
        if self.render_mode == 'human':
            plt.ioff()
            plt.close()
