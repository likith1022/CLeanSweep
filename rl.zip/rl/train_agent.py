from clean_sweep_env import CleanSweepEnv
from q_learning_agent import QLearningAgent

env = CleanSweepEnv(render_mode='human')
agent = QLearningAgent(env)

EPISODES = 100
for episode in range(EPISODES):
    state, _ = env.reset()
    done = False
    total_reward = 0

    while not done:
        action = agent.choose_action(state)
        next_state, reward, done, _, _ = env.step(action)
        agent.learn(state, action, reward, next_state)
        state = next_state
        total_reward += reward

    agent.epsilon *= agent.epsilon_decay
    print(f"Episode {episode + 1}, Total Reward: {total_reward:.2f}")

env.close()
