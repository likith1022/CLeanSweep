import random
import numpy as np

class QLearningAgent:
    def __init__(self, env, alpha=0.1, gamma=0.9, epsilon=1.0, epsilon_decay=0.995):
        self.q_table = {}
        self.env = env
        self.alpha = alpha
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_decay = epsilon_decay

    def get_q(self, state, action):
        return self.q_table.get((tuple(state), action), 0.0)

    def choose_action(self, state):
        if random.random() < self.epsilon:
            return self.env.action_space.sample()
        else:
            q_values = [self.get_q(state, a) for a in range(self.env.action_space.n)]
            return int(np.argmax(q_values))

    def learn(self, state, action, reward, next_state):
        best_next_action = np.argmax([self.get_q(next_state, a) for a in range(self.env.action_space.n)])
        target = reward + self.gamma * self.get_q(next_state, best_next_action)
        self.q_table[(tuple(state), action)] = self.get_q(state, action) + self.alpha * (target - self.get_q(state, action))
